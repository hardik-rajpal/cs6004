// Testcase 12:
// Handling empty class.

class Test12
{  }