Commands:
Note: replace ; (windows) by : on unix systems or your system's default path separator.

Set cwd to 200050048-pa1 and run:

javac -cp '.;<PATH TO SOOT.JAR>' PA1.java
java -cp '.;<PATH TO SOOT.JAR>' PA1

The folder structure is:

testcases
├── tc1
│   ├── lva
│   │   └── tc1.jimple
│   ├── npa
│   │   └── tc1.jimple
│   ├── tc1.java
│   └── tc1.jimple
├── tc2
│   ├── lva
│   │   └── tc2.jimple
│   ├── npa
│   │   └── tc2.jimple
│   ├── tc2.java
│   └── tc2.jimple
├── tc3
│   ├── lva
│   │   └── tc3.jimple
│   ├── npa
│   │   └── tc3.jimple
│   ├── tc3.java
│   └── tc3.jimple
├── tc4
│   ├── lva
│   │   └── tc4.jimple
│   ├── npa
│   │   └── tc4.jimple
│   ├── tc4.java
│   └── tc4.jimple
└── tc5
    ├── lva
    │   └── tc5.jimple
    ├── npa
    │   └── tc5.jimple
    ├── tc5.java
    └── tc5.jimple