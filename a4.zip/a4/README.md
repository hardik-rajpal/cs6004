Commands:
javac testcases/*.java
//Replace ; by : on unix.
javac '.;../soot.jar' *.java
java '.;../soot.jar' PA4
//generates .class files in sootOutput
run .class files in sootOutput and compare with those in testcases.